let cartItems = [];
let totalAmount = 0;

const cartItemsContainer = document.querySelector('.cart-items');
const cartCount = document.querySelector('.cart-count');
const totalPrice = document.querySelector('.total-price');

function addToCart(itemId, itemName, itemPrice) {
  const existingItem = cartItems.find(item => item.id === itemId);

  if (existingItem) {
    alert(`${itemName} já está no carrinho!`);
    return;
  }
  cartItems.push({ id: itemId, name: itemName, price: itemPrice });

  totalAmount += itemPrice;
  updateCartDisplay();
}

function updateCartDisplay() {
  cartItemsContainer.innerHTML = '';

  cartItems.forEach(item => {
    const itemElement = document.createElement('li');
    itemElement.innerHTML = `<span>${item.name}</span> <span>R$${item.price.toFixed(2)}</span>`;
    cartItemsContainer.appendChild(itemElement);
  });

  cartCount.textContent = cartItems.length;
  totalPrice.textContent = `R$${totalAmount.toFixed(2)}`;
}

document.querySelectorAll('.add-to-cart-button').forEach(button => {
  button.addEventListener('click', (event) => {
    const gameCard = event.target.closest('.game-card');
    const itemId = gameCard.getAttribute('data-id');
    const itemName = gameCard.querySelector('h3').textContent;
    const priceText = gameCard.querySelector('.price').textContent;
    const itemPrice = parseFloat(priceText.replace('R$', '').replace(',', '.'));

    addToCart(itemId, itemName, itemPrice);
  });
});
